import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ContactService {
  private contactNameSource = new BehaviorSubject<string>('Contacto');
  contactName$ = this.contactNameSource.asObservable();

  setContactName(name: string) {
    this.contactNameSource.next(name);
  }
}
