import { Component, OnInit } from '@angular/core';
import { VoiceRecorder } from 'capacitor-voice-recorder';
import { ActionSheetController } from '@ionic/angular';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-chat',
  templateUrl: './chat.page.html',
  styleUrls: ['./chat.page.scss'],
  standalone: false
})
export class ChatPage implements OnInit {
  contactName: string = 'Contacto';
  messages: any[] = [
    { id: 1, from: 'other', text: 'Hola! ¿Cómo estás?' },
    { id: 2, from: 'me', text: 'Todo bien, ¿y tú?' },
    { id: 3, from: 'other', text: 'Excelente 😃' }
  ];

  newMessage: string = '';
  isRecording: boolean = false;
  recordTime: number = 0;
  recordInterval: any;
  replyTo: any = null;
  editingMessage: any = null;

  dragStartX: number = 0;
  currentDraggingMsg: any = null;

  constructor(
    private actionSheetCtrl: ActionSheetController,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      if (params['nombre']) this.contactName = params['nombre'];
    });
  }

  sendMessage() {
    if (!this.newMessage.trim()) return;
    const msg = {
      id: Date.now(),
      from: 'me',
      text: this.newMessage,
      replyTo: this.replyTo
    };
    if (this.editingMessage) {
      this.editingMessage.text = this.newMessage;
      this.editingMessage = null;
    } else {
      this.messages.push(msg);
    }
    this.newMessage = '';
    this.replyTo = null;
    this.scrollBottom();
  }

  async startRecording() {
    this.isRecording = true;
    this.recordTime = 0;
    this.recordInterval = setInterval(() => this.recordTime++, 1000);
    await VoiceRecorder.requestAudioRecordingPermission();
    await VoiceRecorder.startRecording();
  }

  async stopRecording() {
    if (!this.isRecording) return;
    clearInterval(this.recordInterval);
    this.isRecording = false;
    const result = await VoiceRecorder.stopRecording();
    if (result.value?.recordDataBase64) {
      const audioUrl = `data:audio/aac;base64,${result.value.recordDataBase64}`;
      this.messages.push({
        id: Date.now(),
        from: 'me',
        audio: audioUrl,
        duration: this.recordTime
      });
      this.scrollBottom();
    }
  }

  private scrollBottom() {
    setTimeout(() => {
      document.querySelector('ion-content')?.scrollToBottom(300);
    }, 100);
  }

  // Drag para acciones
  startDrag(msg: any, event: TouchEvent) {
    this.dragStartX = event.touches[0].clientX;
    this.currentDraggingMsg = msg;
    (event.currentTarget as HTMLElement).classList.add('dragging');
  }

  onDrag(msg: any, event: TouchEvent) {
    if (!this.currentDraggingMsg) return;
    const dragX = event.touches[0].clientX - this.dragStartX;
    if (dragX > 0) {
      (event.currentTarget as HTMLElement).style.transform = `translateX(${Math.min(dragX, 100)}px)`;
    }
  }

  endDrag(msg: any, event: TouchEvent) {
    if (!this.currentDraggingMsg) return;
    (event.currentTarget as HTMLElement).classList.remove('dragging');
    (event.currentTarget as HTMLElement).style.transform = 'translateX(0)';
    const dragEndX = event.changedTouches[0].clientX;
    if (dragEndX - this.dragStartX > 80) this.openMessageActions(msg);
    this.currentDraggingMsg = null;
  }

  async openMessageActions(msg: any) {
    const buttons: any[] = [];
    if (msg.from === 'other') buttons.push({ text: 'Responder', handler: () => this.replyTo = msg });
    if (msg.from === 'me') buttons.push({ text: 'Editar', handler: () => this.editMessage(msg) });
    buttons.push({ text: '👍', handler: () => this.reactMessage(msg, '👍') });
    buttons.push({ text: '😀', handler: () => this.reactMessage(msg, '😀') });
    buttons.push({ text: '❤️', handler: () => this.reactMessage(msg, '❤️') });
    buttons.push({ text: 'Cancelar', role: 'cancel' });

    const actionSheet = await this.actionSheetCtrl.create({ buttons });
    await actionSheet.present();
  }

  editMessage(msg: any) {
    this.newMessage = msg.text;
    this.editingMessage = msg;
  }

  reactMessage(msg: any, emote: string) {
    msg.reaction = emote;
  }
}
