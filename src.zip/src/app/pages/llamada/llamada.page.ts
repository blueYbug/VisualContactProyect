import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Haptics } from '@capacitor/haptics';
import { Howl } from 'howler';
import { NavController, AnimationController } from '@ionic/angular';

@Component({
  selector: 'app-llamada',
  templateUrl: './llamada.page.html',
  styleUrls: ['./llamada.page.scss'],
  standalone: false
})
export class LlamadaPage implements OnInit {
  contactName: string = 'Juan Pérez';
  callStatus: string = 'Llamando...';
  isMuted: boolean = false;
  isSpeaker: boolean = false;
  avatarScale: number = 1;
  ringtone!: Howl;
  callStartTime!: Date;
  timerInterval: any;
  callDuration: string = '00:00';
  hangupBlink: boolean = false;
  avatarPulseInterval: any;

  constructor(
    private navCtrl: NavController,
    private route: ActivatedRoute,
    private animationCtrl: AnimationController
  ) {}

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      if (params['nombre']) this.contactName = params['nombre'];
    });

    this.startCall();
  }

  startCall() {
    this.playRingtone();
    this.startAvatarPulse();

    // Conectar después de 5 segundos
    setTimeout(() => {
      this.callStatus = 'Conectado';
      this.stopRingtone();
      this.stopAvatarPulse();
      this.startTimer();
    }, 5000);
  }

  playRingtone() {
    this.ringtone = new Howl({
      src: ['assets/sonido-llamada.mp3'],
      loop: true,
      volume: 0.5
    });
    this.ringtone.play();
  }

  stopRingtone() {
    if (this.ringtone) this.ringtone.stop();
  }

  hangUp() {
    this.stopRingtone();
    this.stopTimer();
    this.stopAvatarPulse();
    Haptics.vibrate({ duration: 500 });
    this.callStatus = 'Llamada finalizada';
    setTimeout(() => {
      this.navCtrl.navigateBack('/info', {
        queryParams: { nombre: this.contactName }
      });
    }, 500);
  }

  toggleMute() { this.isMuted = !this.isMuted; }
  toggleSpeaker() { this.isSpeaker = !this.isSpeaker; }

  // Botones con efecto “rebote”
  animateButton(event: any) {
    const button = event.currentTarget;
    const animation = this.animationCtrl.create()
      .addElement(button)
      .duration(150)
      .fromTo('transform', 'scale(1)', 'scale(1.2)')
      .fromTo('opacity', '1', '0.8')
      .direction('alternate');
    animation.play();
  }

  // Temporizador de llamada
  startTimer() {
    this.callStartTime = new Date();
    this.timerInterval = setInterval(() => {
      const diff = Math.floor((new Date().getTime() - this.callStartTime.getTime()) / 1000);
      const mins = Math.floor(diff / 60).toString().padStart(2, '0');
      const secs = (diff % 60).toString().padStart(2, '0');
      this.callDuration = `${mins}:${secs}`;
      this.hangupBlink = !this.hangupBlink; // parpadeo rojo
    }, 1000);
  }

  stopTimer() {
    clearInterval(this.timerInterval);
    this.hangupBlink = false;
  }

  // Avatar pulso mientras suena ringtone
  startAvatarPulse() {
    let growing = true;
    this.avatarPulseInterval = setInterval(() => {
      if (growing) {
        this.avatarScale += 0.01;
        if (this.avatarScale >= 1.1) growing = false;
      } else {
        this.avatarScale -= 0.01;
        if (this.avatarScale <= 1) growing = true;
      }
    }, 20);
  }

  stopAvatarPulse() {
    clearInterval(this.avatarPulseInterval);
    this.avatarScale = 1;
  }

  // Escala avatar opcional al scroll
  onScroll(event: any) {
    const scrollTop = event.detail.scrollTop;
    this.avatarScale = Math.max(0.7, 1 - scrollTop / 300);
  }

  formatTime() { return this.callDuration; }
}
